package com.jpmorgan.example.assignments.rkssstock.enums;

public enum StockType {
	COMMON, PREFERRED
}
