package com.jpmorgan.example.assignments.rkssstock.enums;

public enum TradeType {
	BUY, SELL
}
